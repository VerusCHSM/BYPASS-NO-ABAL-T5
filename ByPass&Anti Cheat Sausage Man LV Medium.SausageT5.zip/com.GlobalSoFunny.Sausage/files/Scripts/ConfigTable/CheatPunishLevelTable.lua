local CheatPunishLevelTable = class({}, Assets.req("Scripts.ConfigTable.Base.CheatPunishLevelTableBase"))

--------------------------------------------自动生成--------------------------------------------

return CheatPunishLevelTable
