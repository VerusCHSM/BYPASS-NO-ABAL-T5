local ReportTypeTable = class({}, Assets.req("Scripts.ConfigTable.Base.ReportTypeTableBase"))

--------------------------------------------自动生成--------------------------------------------

return ReportTypeTable
