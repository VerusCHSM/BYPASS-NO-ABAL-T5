local List0 = {
}

local Keys = {}



local AbnormalDataCheckTableBase = {

    -- 记录数
	COUNT = 0,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	game_mod = false,
	head_shot_rate = 9999,
	total_real_kill_num =9999,
	be_other_report = false,
	avg_real_kill_num = 9999,
	check_duration = 9999,

    -- 标识常量
}



return AbnormalDataCheckTableBase